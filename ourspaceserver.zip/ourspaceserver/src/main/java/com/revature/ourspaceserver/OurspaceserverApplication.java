package com.revature.ourspaceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OurspaceserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurspaceserverApplication.class, args);
	}

}
